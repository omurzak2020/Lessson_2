package kg.geektech.android3.lessson_2.data.remote;

public class Endpoints {

    public static final String GET_FILM = "films/{id}";

    public static final String GET_FILMS = "films";
}
