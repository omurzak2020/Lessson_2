package kg.geektech.android3.lessson_2.data.model;

import androidx.recyclerview.widget.RecyclerView;

public class adapter {
}
